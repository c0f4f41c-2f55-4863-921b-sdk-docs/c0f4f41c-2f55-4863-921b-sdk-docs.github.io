﻿namespace SocketIOClient.Transport
{
    public enum TransportMessageType
    {
        Text = 0,
        Binary = 1
    }
}
