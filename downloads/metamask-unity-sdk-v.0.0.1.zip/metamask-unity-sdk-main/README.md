# Metamask Unity SDK

MetaMask SDK for Unity

## How it works

You can import the MetaMask SDK into your Unity game to enable users to easily connect with their MetaMask Mobile wallet.

The SDK will render a QR code on the UI which users can scan with their MetaMask Mobile app and now you can use all the [`ethereum` methods available](guide/ethereum-provider.html) right from your game!

## Getting started

### 1. Install

To install the module you simply have to download/clone the [repository](https://github.com/MetaMask/metamask-unity-sdk) and import it via the **Package Manager**.

To do that go to the Window menu > Package Manager. Select the + and "Add Package from Disk" and select the folder where you have downloaded/cloned the repository and select the `package.json` file and select "Open". You should see the `MetaMask SDK` package now lister in the project packages.

### 2. Add the MetaMaskSDKQRCodeImage prefab

The first thing to do is to create a **canvas** in your scene and add the **MetaMaskSDKQRCodeImage** prefab to it. It is located in the package directory > Runtime folder.

This is a `Raw Image` that is used by the connect script to display the QRCode that needs to be scanned by MetaMask mobile app to establish the connection.

You should have something like that:\
<img src="./Documentation/canvas.png" width="300">

### 3. Prompt the QR Code for users to scan with MetaMask Mobile

In order to connect your application, you can call `MMSDK.ethereum.connect` with your dapp information like that:

```
var dappMetadata = new MMSDK.DappMetadata
    {
        name = "myapp",
        url = "myapp.com"
    };

// This is the same as calling "eth_requestAccounts"
var response = await MMSDK.ethereum.connect(dappMetadata);
```

This will render the QRCode on the UI for your users to scan with MetaMask Mobile. After user scan this QR code, a connect screen will appear in MetaMask Mobile where the user can now approve the connection with your game.

### 4. You can now call any ethereum provider method

Once the connection has been established, you are now able to call any `ethereum` method listed on the [the Ethereum Provider API](https://github.com/MetaMask/metamask-sdk-docs/blob/main/docs/guide/ethereum-provider.md)

Here's a simple example of a `request` method, specifically an `eth_chainId` one:

```
var requestChainId = new MMSDK.EthereumRequest
    {
        method = "eth_chainId",
        @params = new string[] { }
    };

var responseChainId = await MMSDK.ethereum.request(requestChainId);
```

## Available Prefabs

Here's the list of the available prefabs:

- **MetaMaskSDKQRCodeImage** (mandatory): this is the only **mandatory** prefab and it's a `Raw Image` that is used to display the connection QRCode
- **ButtonConnect**: it's a sample button with the `ConnectButton` script attached to it and called on "on click" event
- **ButtonSendTransaction**: it's a sample button with the `SendTransactionButton` script attached to it and called on "on click" event
- **ButtonSign**: it's a sample button with the `SignButton` script attached to it and called on "on click" event

**MetaMaskSDKQRCodeImage** is mandatory.

## Package Structure

- **Documentation**: contains the documentation
- **Packages**: contains some of the packages that could not be imported automatically. In particular the `SocketIO` module
- **Plugins**: contains the plugins needed by the package. In particular the cryptographic library (BouncyCastle)
- **Runtime**: contains the main scripts to be used in your project. You can find a more detailed description of those script below.
- **Samples**: contains a test application scene that can be used as a referral for your project
- **UserSettings**: contains user settings
- **CHANGELOG.md**: the package changelog
- **LICENSE.md**: the package license
- **package.json**: the json file describing the package
- **README.md**: this file
- **Third Party Notices.md**: third party notices

## Runtime

The `Runtime` folder contains the cs scripts that you need to import or use in your script for your project.

### MSDK.cs

This is the main SDK class of the package.

### MSDK_Ethereum.cs

This gives to your project access to the `ethereum` method.

### MSDK_KeyExchange.cs

This class is used to establish a secure connection between your project application and the MetaMask Mobile app.

### MSDK_ECDH.cs

This class has the cryptographic methods used for the initial secure key exchange and the encryption/decryption methods used to secure the communication between your project application and MetaMask mobile app.

### QRCodeCube.cs

This is an example script used by the sample scene. This QRCode cube is used to show the QR Code that the user needs to scan with the MetaMask mobile app to establish the connection.

### ConnectButton.cs

This is an example script used by the sample scene and shows you how to establish the fist connection between your appliction and the MetaMask mobile app.

### SignButton.cs

This is an example script used by the sample scene and shows you how to sign a message sent from your appliction with the MetaMask mobile app.

### SendTransactionButton.cs

This is an example script used by the sample scene and shows you how to request the sending of a transaction sent from your appliction to the MetaMask mobile app.

### **Examples**

- [Unity examples]()

### **Recordings**

- [Unity game](https://recordit.co/QN196nsR1d)
