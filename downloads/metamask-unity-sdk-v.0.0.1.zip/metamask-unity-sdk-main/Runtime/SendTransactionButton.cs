using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;
using UnityEngine.UI;


public class Transcation
{   

  public string to { get; set; }
  public string from { get; set; }
  public string value { get; set; }
}

public class SendTransactionButton : MonoBehaviour
{
    public async Task MakeRequest(){
        var transactionParams = new Transcation{
            to = "0xd0059fB234f15dFA9371a7B45c09d451a2dd2B5a",
            from = MMSDK.ethereum.selectedAddress,
            value = "0x0"
        };

        Transcation[] txParamsArray = new Transcation[] { transactionParams };

        var request = new MMSDK.EthereumRequest
        {
            method = "eth_sendTransaction",
            @params = txParamsArray
        };

        var response = await MMSDK.ethereum.request(request);

        Debug.Log("reponse starting");
        Debug.Log(response);
        Text textObject = GameObject.Find("Logs").GetComponent<Text>();
        textObject.text += ("\n\n Tx response: \n" + response);
    }
    public async void Click(){
        await MakeRequest();
    }
}
