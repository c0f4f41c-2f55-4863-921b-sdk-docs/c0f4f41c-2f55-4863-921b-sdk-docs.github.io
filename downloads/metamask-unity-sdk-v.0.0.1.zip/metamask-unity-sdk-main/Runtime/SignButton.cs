using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Threading.Tasks;
using UnityEngine.UI;
public class Sign
{   
  public string from { get; set; }
  public string value { get; set; }
}

   

public class SignButton : MonoBehaviour
{
     public async Task MakeRequest(){
        
        string msgParams = "{\"domain\":{\"chainId\":1,\"name\":\"Ether Mail\",\"verifyingContract\":\"0xCcCCccccCCCCcCCCCCCcCcCccCcCCCcCcccccccC\",\"version\":\"1\"},\"message\":{\"contents\":\"Hello, Bob!\",\"from\":{\"name\":\"Cow\",\"wallets\":[\"0xCD2a3d9F938E13CD947Ec05AbC7FE734Df8DD826\",\"0xDeaDbeefdEAdbeefdEadbEEFdeadbeEFdEaDbeeF\"]},\"to\":[{\"name\":\"Bob\",\"wallets\":[\"0xbBbBBBBbbBBBbbbBbbBbbbbBBbBbbbbBbBbbBBbB\",\"0xB0BdaBea57B0BDABeA57b0bdABEA57b0BDabEa57\",\"0xB0B0b0b0b0b0B000000000000000000000000000\"]}]},\"primaryType\":\"Mail\",\"types\":{\"EIP712Domain\":[{\"name\":\"name\",\"type\":\"string\"},{\"name\":\"version\",\"type\":\"string\"},{\"name\":\"chainId\",\"type\":\"uint256\"},{\"name\":\"verifyingContract\",\"type\":\"address\"}],\"Group\":[{\"name\":\"name\",\"type\":\"string\"},{\"name\":\"members\",\"type\":\"Person[]\"}],\"Mail\":[{\"name\":\"from\",\"type\":\"Person\"},{\"name\":\"to\",\"type\":\"Person[]\"},{\"name\":\"contents\",\"type\":\"string\"}],\"Person\":[{\"name\":\"name\",\"type\":\"string\"},{\"name\":\"wallets\",\"type\":\"address[]\"}]}}";
        string from = MMSDK.ethereum.selectedAddress;

        var paramsArray = new string[] { from, msgParams };

        var request = new MMSDK.EthereumRequest
        {
            method = "eth_signTypedData_v4",
            @params = paramsArray
        };
        var response = await MMSDK.ethereum.request(request);

        Debug.Log("reponse starting");
        Debug.Log(response);
        Text textObject = GameObject.Find("Logs").GetComponent<Text>();
        textObject.text += ("\n\n Signing response: \n" + response);
        Debug.Log("reponse ending");
        Debug.Log(MMSDK.ethereum.chainId);
    }
    public async void Click(){
        await MakeRequest();
    }
}