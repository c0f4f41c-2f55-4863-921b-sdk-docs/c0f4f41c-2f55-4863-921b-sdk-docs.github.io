using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using SocketIOClient;
using Newtonsoft.Json;
using System.Threading.Tasks;
using System.Text.Json;
using static QRCodeCube;
using UnityEngine.UI;
using static MMSDK.KeyExchange;

namespace MMSDK {
    public delegate void Notify();  // delegate
    public class SDK
    {
        string id;
        public event Notify ClientsReady; // event

        bool connected;

        private bool keysExchanged = false;

        public KeyExchange keyExchange;

        public SocketIOUnity socket;

        private bool paused = false;

        public string name;
        public string url;

        private class RequestInfo
        {   
            public string type { get; set; }
            public OriginatorInfo originatorInfo { get; set; }
        }

        private class Message
        {   
            public string id { get; set; }
            public object message { get; set; }
        }

        private class OriginatorInfo
        {   
            public string title { get; set; }
            public string url { get; set; }
        }

        private Message prepareMessage(object sendMessage, bool encrypt){
            object messageToSend = null;
            if(encrypt){
                messageToSend= this.keyExchange.encryptMessage(sendMessage);
            }else{
                messageToSend = sendMessage;
            }

            var message = new Message
                {
                    id = this.id,
                    message = messageToSend
                };

            return message;
        }

        public void sendMessage(object sendMessage, bool encrypt){
            if(this.paused){
                Debug.Log("WILL SEND ONCE WALLET IS OPENED AGAIN");
                this.ClientsReady = () =>  {
                   Debug.Log("SENDING NOW");
                   socket.Emit("message", prepareMessage(sendMessage, encrypt));
                };
            }else{
                socket.Emit("message", prepareMessage(sendMessage, encrypt));
            }
           
        }

        void sendOriginatorInfo(){
            var originatorInfo = new OriginatorInfo
            {
                title = this.name,
                url = this.url
            };
            var requestInfo = new RequestInfo
            {
                type = "originator_info",
                originatorInfo = originatorInfo
            };
            //string encrypted = this.keyExchange.encryptMessage(requestInfo);
            this.sendMessage(requestInfo, true);
        }

        void receiveMessages(string channelId){
            this.socket.On("message-" + channelId, (response) =>
            {
                var message = response.GetValue(0);
                var messagedReceived = message.GetProperty("message");
                if(!keysExchanged){
                    if(messagedReceived.GetProperty("type").ToString() == "key_handshake_SYNACK"){
                        this.keyExchange.onOtherPublickKey(messagedReceived.GetProperty("pubkey").ToString());
                        var keyExchangeACK = this.keyExchange.getKeyExchangeMessage("key_handshake_ACK");

                        this.sendMessage(keyExchangeACK, false);

                        this.keysExchanged = true;
                        this.sendOriginatorInfo();
                    }
                }else{
                    
                    if(this.paused && messagedReceived.ValueKind != JsonValueKind.String){
                        if(messagedReceived.TryGetProperty("type", out var keyType)){
                            if(keyType.ToString() == "key_handshake_start"){
                                this.keysExchanged = false;
                                this.paused = false;
                                this.connected = false;
                                var keyExchangeSYN = this.keyExchange.getKeyExchangeMessage("key_handshake_SYN");
                                this.sendMessage(keyExchangeSYN, false);

                                return;
                            }
                        }
                    }

                    string decryptedText = this.keyExchange.decryptMessage(messagedReceived.ToString());

                    var decryptedMessage = JsonDocument.Parse(decryptedText).RootElement;

                     if(decryptedMessage.TryGetProperty("type", out var type)){
                         if(type.ToString() == "pause"){
                            this.paused = true;
                            return;
                         }else if(type.ToString() == "ready"){
                            this.paused = false;
                            ClientsReady.Invoke();
                        }
                     }

                    if(!connected){
                        if(decryptedMessage.GetProperty("type").ToString() == "wallet_info")
                        {
                            connected = true;
                            ClientsReady.Invoke();
                            this.paused = false;
                            return;
                        }
                    }

                    if(decryptedMessage.GetProperty("data").TryGetProperty("id", out var id)){
                        ethereum.receiveRequest(id.ToString(), decryptedMessage.GetProperty("data"));
                    }else{
                        ethereum.receiveEvent(decryptedMessage.GetProperty("data"));
                    }
                }
            });

            this.socket.On("clients_connected-" + channelId, (response) =>
            {
                Debug.Log("Clients Connected");

                if(!keysExchanged){
                    var keyExchangeSYN = this.keyExchange.getKeyExchangeMessage("key_handshake_SYN");
                    
                    this.sendMessage(keyExchangeSYN, false);
                }
            });

            this.socket.On("clients_disconnected-" + channelId, (response) =>
            {
                Debug.Log("Clients disconnected");

                if(!this.paused){
                    this.connected = false;
                    this.keysExchanged = false;
                    this.id = null;
                    ethereum.disconnect();
                }
            });
        }

        public void connect(){

            bool isMobile = SystemInfo.deviceType == DeviceType.Handheld;
            ethereum.isMobile = isMobile;
            QRCodeCube.isMobile = isMobile;

            string id = System.Guid.NewGuid().ToString();
            this.id = id;
            this.keyExchange = new KeyExchange();
            this.keyExchange.start();
            string url = "https://metamask.app.link/connect?channelId=" + System.Uri.EscapeDataString(id) + "&pubkey=" + System.Uri.EscapeDataString(this.keyExchange.myPublicKey);

            Debug.Log(url);

            this.socket = new SocketIOUnity("https://socket.codefi.network", new SocketIOOptions
            {
                ExtraHeaders = new Dictionary<string, string>
                {
                    {"User-Agent", "SocketIOClient"}
                }
            });

            this.socket.OnConnected += (sender, e) =>
            {
                Debug.Log("Socket Connected");
                
                this.receiveMessages(this.id);

                socket.Emit("join_channel",  this.id);
            };

            this.socket.ConnectAsync();

            QRCodeCube.QRCode = url;
            QRCodeCube.attatch();
            
            return;
        }
    }
}