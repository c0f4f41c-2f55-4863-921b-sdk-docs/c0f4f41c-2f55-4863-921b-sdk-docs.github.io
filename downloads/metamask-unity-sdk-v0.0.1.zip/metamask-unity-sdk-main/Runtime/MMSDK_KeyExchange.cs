using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using Org.BouncyCastle.Crypto;
using Org.BouncyCastle.Math;
using static MMSDK.ECDH;
using Newtonsoft.Json;


namespace MMSDK {
    public class KeyExchange{

        private AsymmetricCipherKeyPair myECDH;
        public string myPublicKey;

        private BigInteger secretKey;

        public void start(){
            this.myECDH = generateECDH ();
            this.myPublicKey = getPublicKey(myECDH);
        }

        public class KeyExchangeMessage {
            public string type { get; set; }
            public string pubkey { get; set; }
        }

        public KeyExchangeMessage getKeyExchangeMessage(string type){
            KeyExchangeMessage keyExchangeACK = new KeyExchangeMessage{
                type = type
            };

            return keyExchangeACK;
        }

        public void onOtherPublickKey(string pubkey){
            this.secretKey = computeECDHSecret (myECDH, pubkey);
        }

        public string decryptMessage(string message){
            return decryptAuthIV(message, this.secretKey.ToByteArrayUnsigned ());
        }

        public string encryptMessage(object message){
            return encryptAuthIV(JsonConvert.SerializeObject(message), this.secretKey.ToByteArrayUnsigned ());
        }
    }

}