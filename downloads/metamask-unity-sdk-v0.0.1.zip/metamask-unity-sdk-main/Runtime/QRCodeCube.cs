using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using ZXing;
using ZXing.QrCode;
using UnityEngine.UI;

public class QRCodeCube
{

    static public string QRCode;
    static public bool isMobile;

    private static Color32[] Encode(string textForEncoding, 
        int width, int height) {
        var writer = new BarcodeWriter {
            Format = BarcodeFormat.QR_CODE,
            Options = new QrCodeEncodingOptions {
            Height = height,
            Width = width
            }
        };
        return writer.Write(textForEncoding);
    }
    public static Texture2D generateQR(string text) {
        Texture2D encoded = new Texture2D (256, 256);
        var color32 = Encode(text, encoded.width, encoded.height);
        encoded.SetPixels32(color32);
        encoded.Apply();
        return encoded;
    }

    public static void attatch(){
        if (isMobile)
        {
            Application.OpenURL(QRCode);
        } else {
            Texture2D myQR = generateQR(QRCode);
            GameObject.Find("MetaMaskSDKQRCodeImage").GetComponent<RawImage>().texture = myQR;
        }
    }
}
