using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using System.Text.Json;
using System.Threading.Tasks;

namespace MMSDK {

    public class EthereumRequest
    {   
        public object @params { get; set; }
        public string method { get; set; }
        
        public string id { get; set; }
    }

    public class DappMetadata
    {   
        public string name  { get; set; }
        public string url { get; set; }
    }

    public class ethereum {
        public static bool connected;

        public static bool isMobile;

        public static string selectedAddress = null;
        public static string chainId;

        private static SDK sdk;
        private static DappMetadata dappMetadata;

        private class SubmittedRequest
        {
            public string method {get; set;}
            public TaskCompletionSource<object> promise;
        }

        private static Dictionary<string,SubmittedRequest> submittedRequests = new Dictionary<string,SubmittedRequest>();

        private static void handleAccountsChanged(JsonElement accounts){
            try{
                selectedAddress = accounts[0].ToString();
            }catch{
                selectedAddress = null;
            };
        }

        private static void handleChainIdChanged(string newChainId){
            chainId = newChainId;
        }

        public static void disconnect(){
            connected = false;
            selectedAddress = null;
            chainId = null;
        }

        public static void receiveRequest(string id, JsonElement data){
            if(data.TryGetProperty("error", out var error)){
                submittedRequests[id].promise.SetException(new System.Exception(error.ToString()));
            }else if(data.TryGetProperty("result", out var result)){
                if(submittedRequests[id].method == "metamask_getProviderState"){
                    handleAccountsChanged(result.GetProperty("accounts"));
                    handleChainIdChanged(result.GetProperty("chainId").ToString());
                } else if(submittedRequests[id].method == "eth_requestAccounts"){
                    handleAccountsChanged(result);
                } else if(submittedRequests[id].method == "eth_chainId"){
                    handleChainIdChanged(result.ToString());
                }
                submittedRequests[id].promise.SetResult(result);
            }
        }

        public static void receiveEvent(JsonElement data){
            string method = data.GetProperty("method").ToString();
            if(method == "metamask_accountsChanged"){
                handleAccountsChanged(data.GetProperty("params"));
            }else if(method == "metamask_chainChanged"){
                handleChainIdChanged(data.GetProperty("params").GetProperty("chainId").ToString());
            }
        }

        static void sendRequest(string id, EthereumRequest args, bool openDeeplink){
            args.id = id;

            sdk.sendMessage(args, true);

            if(openDeeplink && isMobile){
                Application.OpenURL("https://metamask.app.link");
            }
        }

        static void initializeState(){
            var req = new EthereumRequest
            {
                method = "metamask_getProviderState",
                @params = new string[] { }
            };
            request(req);
        }

        static void ClientsReady(TaskCompletionSource<object> tcs){
            connected = true;
            initializeState();
            string method = "eth_requestAccounts";
            var req = new EthereumRequest
            {
                method = "eth_requestAccounts",
                @params = new string[] { }
            };
            string id = System.Guid.NewGuid().ToString();

            SubmittedRequest submittedRequest = new SubmittedRequest
            {
                method = method,
                promise = tcs
            };

            submittedRequests.Add(id, submittedRequest);
            sendRequest(id, req, false);
        }

        public static bool shouldOpenMM(string method){
            if(method == "eth_requestAccounts" && selectedAddress == null) return true;

            string[] methodsToRedirect = { 
                "eth_sendTransaction",
                "eth_signTransaction",
                "eth_sign",
                "personal_sign",
                "eth_signTypedData",
                "eth_signTypedData_v3",
                "eth_signTypedData_v4",
                "wallet_watchAsset",
                "wallet_addEthereumChain",
                "wallet_switchEthereumChain"};

             foreach (string redirectMethod in methodsToRedirect)
                {
                    if (redirectMethod.Equals (method))
                    {
                        return true;
                    }
                }

            return false;
        }

        public static Task<object> request(EthereumRequest args)
        {   
            var tcs = new TaskCompletionSource<object>();
            if(args?.method == "eth_requestAccounts" && !connected){
                sdk = new SDK();
                sdk.name = dappMetadata.name;
                sdk.url = dappMetadata.url;
                sdk.connect();
                sdk.ClientsReady += () => ClientsReady(tcs);
            }else if(!connected){
                throw new System.Exception("Wait until MetaMask is connected");
            }else {
                string id = System.Guid.NewGuid().ToString();

                SubmittedRequest submittedRequest = new SubmittedRequest
                {
                    method = args?.method,
                    promise = tcs
                };

                submittedRequests.Add(id, submittedRequest);
                sendRequest(id, args, shouldOpenMM(args?.method));
            }
            return tcs.Task;
        }

        public static Task<object> connect(DappMetadata dappMetadataToSet)
        {   
            dappMetadata = dappMetadataToSet;

            var requestToSend = new MMSDK.EthereumRequest
            {
                method = "eth_requestAccounts",
                @params = new string[] { }
            };

            return MMSDK.ethereum.request(requestToSend);
        }
    }
}