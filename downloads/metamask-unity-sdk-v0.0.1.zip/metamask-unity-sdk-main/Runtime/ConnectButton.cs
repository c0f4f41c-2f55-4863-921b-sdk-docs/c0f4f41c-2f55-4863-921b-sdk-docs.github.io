using System.Collections;
using System.Collections.Generic;
using UnityEngine;
using static MMSDK.EthereumRequest;
using static MMSDK.ethereum;
using UnityEngine.UI;
using System.Threading.Tasks;

public class ConnectButton : MonoBehaviour
{
    public async Task MakeRequest(){
        var dappMetadata = new MMSDK.DappMetadata
        {
            name = "myapp",
            url = "myapp.com"
        };

        // This is the same as calling "eth_requestAccounts"
        var response = await MMSDK.ethereum.connect(dappMetadata);

        Debug.Log("reponse starting");
        Debug.Log(response);
        Text textObject = GameObject.Find("Logs").GetComponent<Text>();
        textObject.text += ("\n\n Connected with account:\n" + response);
        Debug.Log("reponse ending");

        var requestChainId = new MMSDK.EthereumRequest
        {
            method = "eth_chainId",
            @params = new string[] { }
        };
        var responseChainId = await MMSDK.ethereum.request(requestChainId);
        
        Debug.Log("THIS IS THE SELECTED ADDRESS");
        Debug.Log(MMSDK.ethereum.selectedAddress);
        Debug.Log("THIS IS THE CHAINID");
        Debug.Log(MMSDK.ethereum.chainId);
    }
    public async void Click(){
        await MakeRequest();       
    }
}
